CREATE DATABASE IF NOT EXISTS lab09_jpa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lab09_jpa;

CREATE TABLE sinh_vien (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ma_sinh_vien VARCHAR(20) NOT NULL UNIQUE,
    ho_ten VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    lop VARCHAR(50),
    ngay_sinh DATE
);

CREATE TABLE sach (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ma_sach VARCHAR(20) NOT NULL UNIQUE,
    ten_sach VARCHAR(150) NOT NULL,
    tac_gia VARCHAR(100),
    nxb VARCHAR(100),
    nam_xb INT
);

CREATE TABLE san_pham (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ma_sp VARCHAR(20) NOT NULL UNIQUE,
    ten_sp VARCHAR(150) NOT NULL,
    mo_ta TEXT,
    gia DOUBLE NOT NULL,
    so_luong INT NOT NULL
);