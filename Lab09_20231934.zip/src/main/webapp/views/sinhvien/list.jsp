<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html><head><title>Danh sách Sinh viên</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-4">
    <h2>Danh sách Sinh viên (Dữ liệu từ MySQL qua JPA)</h2>
    <a href="${pageContext.request.contextPath}/index.jsp" class="btn btn-secondary btn-sm mb-3">Về trang chủ</a>
    <a href="sinh-vien?action=new" class="btn btn-success btn-sm mb-3">Thêm sinh viên</a>
    
    <form method="get" action="sinh-vien" class="d-flex mb-3">
        <input type="text" name="keyword" class="form-control me-2" placeholder="Tìm theo tên/lớp..." value="${param.keyword}">
        <button type="submit" class="btn btn-primary">Tìm</button>
    </form>
    
    <table class="table table-bordered table-striped">
        <thead class="table-dark"><tr><th>ID</th><th>Mã SV</th><th>Họ tên</th><th>Email</th><th>Lớp</th><th>Ngày Sinh</th><th>Thao tác</th></tr></thead>
        <tbody>
            <c:forEach var="sv" items="${dsSinhVien}">
            <tr>
                <td>${sv.id}</td><td>${sv.maSinhVien}</td><td>${sv.hoTen}</td><td>${sv.email}</td><td>${sv.lop}</td><td>${sv.ngaySinh}</td>
                <td>
                    <a href="sinh-vien?action=edit&id=${sv.id}" class="btn btn-warning btn-sm">Sửa</a>
                    <a href="sinh-vien?action=delete&id=${sv.id}" class="btn btn-danger btn-sm" onclick="return confirm('Chắc chắn xóa?');">Xóa</a>
                </td>
            </tr>
            </c:forEach>
        </tbody>
    </table>
</body></html>