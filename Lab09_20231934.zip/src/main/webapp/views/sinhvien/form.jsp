<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><head><title>Form Sinh Viên</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-4">
    <h2>${sv == null ? 'Thêm Sinh viên mới' : 'Cập nhật Sinh viên'}</h2>
    <form method="post" action="sinh-vien" class="card p-4 shadow-sm" style="max-width: 500px;">
        <input type="hidden" name="id" value="${sv.id}">
        <div class="mb-3"><label>Mã SV:</label><input type="text" name="maSinhVien" value="${sv.maSinhVien}" class="form-control" required></div>
        <div class="mb-3"><label>Họ tên:</label><input type="text" name="hoTen" value="${sv.hoTen}" class="form-control" required></div>
        <div class="mb-3"><label>Email:</label><input type="email" name="email" value="${sv.email}" class="form-control"></div>
        <div class="mb-3"><label>Lớp:</label><input type="text" name="lop" value="${sv.lop}" class="form-control"></div>
        <div class="mb-3"><label>Ngày Sinh:</label><input type="date" name="ngaySinh" value="${sv.ngaySinh}" class="form-control"></div>
        <div>
            <button type="submit" class="btn btn-primary">Lưu</button>
            <a href="sinh-vien" class="btn btn-secondary">Hủy</a>
        </div>
    </form>
</body></html>