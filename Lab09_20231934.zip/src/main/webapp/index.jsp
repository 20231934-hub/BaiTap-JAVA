<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><head><title>Lab 9 - JPA</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
    <div class="container text-center mt-5">
        <h1 class="text-primary mb-4">Lab 9 - Tích hợp JPA: Entity, Repository, Transaction</h1>
        <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
            <a href="sinh-vien" class="btn btn-primary btn-lg">Quản lý Sinh Viên (JPA)</a>
            <a href="#" class="btn btn-outline-secondary btn-lg">Quản lý Sách (JPA)</a>
            <a href="#" class="btn btn-outline-success btn-lg">Quản lý Sản Phẩm (JPA)</a>
        </div>
    </div>
</body></html>