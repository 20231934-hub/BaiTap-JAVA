package vn.edu.eaut.lab9.repository;
import jakarta.persistence.EntityManager;
import vn.edu.eaut.lab9.config.JPAUtil;
import vn.edu.eaut.lab9.model.SinhVien;
import java.util.List;

public class SinhVienRepository extends BaseRepository<SinhVien> {
    public SinhVienRepository() { super(SinhVien.class); }

    public List<SinhVien> search(String keyword) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            String jpql = "SELECT s FROM SinhVien s WHERE LOWER(s.hoTen) LIKE :kw OR LOWER(s.lop) LIKE :kw";
            return em.createQuery(jpql, SinhVien.class)
                     .setParameter("kw", "%" + keyword.toLowerCase() + "%")
                     .getResultList();
        } finally { em.close(); }
    }
}