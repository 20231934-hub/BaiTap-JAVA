package vn.edu.eaut.lab9.model;
import jakarta.persistence.*;

@Entity
@Table(name = "sach")
public class Sach {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer id;
    @Column(name = "ma_sach", nullable = false, unique = true, length = 20) private String maSach;
    @Column(name = "ten_sach", nullable = false, length = 150) private String tenSach;
    @Column(name = "tac_gia", length = 100) private String tacGia;
    private String nxb;
    @Column(name = "nam_xb") private Integer namXb;

    public Sach() {}
    public Integer getId() { return id; } public void setId(Integer id) { this.id = id; }
    public String getMaSach() { return maSach; } public void setMaSach(String maSach) { this.maSach = maSach; }
    public String getTenSach() { return tenSach; } public void setTenSach(String tenSach) { this.tenSach = tenSach; }
    public String getTacGia() { return tacGia; } public void setTacGia(String tacGia) { this.tacGia = tacGia; }
    public String getNxb() { return nxb; } public void setNxb(String nxb) { this.nxb = nxb; }
    public Integer getNamXb() { return namXb; } public void setNamXb(Integer namXb) { this.namXb = namXb; }
}