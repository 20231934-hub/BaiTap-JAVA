package vn.edu.eaut.lab9.controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.edu.eaut.lab9.model.SinhVien;
import vn.edu.eaut.lab9.repository.SinhVienRepository;
import java.io.IOException;
import java.time.LocalDate;

@WebServlet("/sinh-vien")
public class SinhVienController extends HttpServlet {
    private final SinhVienRepository repo = new SinhVienRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        if ("new".equals(action)) { req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req, resp); return; }
        if ("edit".equals(action)) { req.setAttribute("sv", repo.findById(Integer.parseInt(req.getParameter("id")))); req.getRequestDispatcher("/views/sinhvien/form.jsp").forward(req, resp); return; }
        if ("delete".equals(action)) { repo.delete(Integer.parseInt(req.getParameter("id"))); resp.sendRedirect(req.getContextPath() + "/sinh-vien"); return; }
        
        String keyword = req.getParameter("keyword");
        if (keyword == null || keyword.isBlank()) req.setAttribute("dsSinhVien", repo.findAll());
        else req.setAttribute("dsSinhVien", repo.search(keyword));
        
        req.getRequestDispatcher("/views/sinhvien/list.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String idStr = req.getParameter("id");
        String ngaySinhStr = req.getParameter("ngaySinh");
        LocalDate ngaySinh = (ngaySinhStr != null && !ngaySinhStr.isEmpty()) ? LocalDate.parse(ngaySinhStr) : null;
        
        SinhVien sv = new SinhVien();
        if (idStr != null && !idStr.isEmpty()) sv.setId(Integer.parseInt(idStr));
        sv.setMaSinhVien(req.getParameter("maSinhVien"));
        sv.setHoTen(req.getParameter("hoTen"));
        sv.setEmail(req.getParameter("email"));
        sv.setLop(req.getParameter("lop"));
        sv.setNgaySinh(ngaySinh);
        
        if (sv.getId() == null) repo.save(sv); else repo.update(sv);
        resp.sendRedirect(req.getContextPath() + "/sinh-vien");
    }
}