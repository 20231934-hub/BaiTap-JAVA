package vn.edu.eaut.lab9.repository;
import jakarta.persistence.*;
import vn.edu.eaut.lab9.config.JPAUtil;
import java.util.List;

public abstract class BaseRepository<T> {
    private final Class<T> type;
    public BaseRepository(Class<T> type) { this.type = type; }

    public List<T> findAll() {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT t FROM " + type.getSimpleName() + " t ORDER BY t.id DESC", type).getResultList();
        } finally { em.close(); }
    }

    public T findById(Integer id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        try { return em.find(type, id); } finally { em.close(); }
    }

    public void save(T entity) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin(); em.persist(entity); tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback(); throw ex;
        } finally { em.close(); }
    }

    public void update(T entity) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin(); em.merge(entity); tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback(); throw ex;
        } finally { em.close(); }
    }

    public void delete(Integer id) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            T entity = em.find(type, id);
            if (entity != null) em.remove(entity);
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback(); throw ex;
        } finally { em.close(); }
    }
}