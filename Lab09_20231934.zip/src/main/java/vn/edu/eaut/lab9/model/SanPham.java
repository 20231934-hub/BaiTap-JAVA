package vn.edu.eaut.lab9.model;
import jakarta.persistence.*;

@Entity
@Table(name = "san_pham")
public class SanPham {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer id;
    @Column(name = "ma_sp", nullable = false, unique = true, length = 20) private String maSp;
    @Column(name = "ten_sp", nullable = false, length = 150) private String tenSp;
    @Column(name = "mo_ta", columnDefinition = "TEXT") private String moTa;
    @Column(nullable = false) private Double gia;
    @Column(name = "so_luong", nullable = false) private Integer soLuong;

    public SanPham() {}
    public Integer getId() { return id; } public void setId(Integer id) { this.id = id; }
    public String getMaSp() { return maSp; } public void setMaSp(String maSp) { this.maSp = maSp; }
    public String getTenSp() { return tenSp; } public void setTenSp(String tenSp) { this.tenSp = tenSp; }
    public String getMoTa() { return moTa; } public void setMoTa(String moTa) { this.moTa = moTa; }
    public Double getGia() { return gia; } public void setGia(Double gia) { this.gia = gia; }
    public Integer getSoLuong() { return soLuong; } public void setSoLuong(Integer soLuong) { this.soLuong = soLuong; }
}