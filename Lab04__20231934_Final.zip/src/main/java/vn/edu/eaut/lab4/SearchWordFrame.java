package vn.edu.eaut.lab4;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.file.Files;
import java.util.List;

public class SearchWordFrame extends JFrame {
    private JTextField txtKeyword;
    private JButton btnChoose, btnSearch;
    private JTextArea txtResult;
    private JLabel lblStatus;
    private File selectedFile;

    public SearchWordFrame() {
        setTitle("Bài 7 - Tìm kiếm từ khóa");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        txtKeyword = new JTextField(15);
        btnChoose = new JButton("Chọn file");
        btnSearch = new JButton("Tìm kiếm");
        lblStatus = new JLabel("Chưa chọn file");
        txtResult = new JTextArea();
        txtResult.setEditable(false);
        
        JPanel pnlTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlTop.add(btnChoose); pnlTop.add(new JLabel("Từ khóa:")); pnlTop.add(txtKeyword); pnlTop.add(btnSearch);
        
        add(pnlTop, BorderLayout.NORTH);
        add(new JScrollPane(txtResult), BorderLayout.CENTER);
        add(lblStatus, BorderLayout.SOUTH);
        
        btnChoose.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                selectedFile = chooser.getSelectedFile();
                lblStatus.setText("File: " + selectedFile.getName());
            }
        });
        
        btnSearch.addActionListener(e -> searchWord());
    }

    private void searchWord() {
        String kw = txtKeyword.getText().trim().toLowerCase();
        if (selectedFile == null || kw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chọn file và nhập từ khóa!"); return;
        }
        btnSearch.setEnabled(false);
        txtResult.setText("");
        lblStatus.setText("Đang tìm...");
        
        SwingWorker<Integer, String> worker = new SwingWorker<>() {
            @Override
            protected Integer doInBackground() throws Exception {
                int count = 0;
                try (BufferedReader br = Files.newBufferedReader(selectedFile.toPath())) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if (line.toLowerCase().contains(kw)) {
                            publish(line); count++;
                        }
                    }
                }
                return count;
            }
            @Override
            protected void process(List<String> chunks) {
                for (String s : chunks) txtResult.append(s + "\n");
            }
            @Override
            protected void done() {
                try {
                    lblStatus.setText("Tìm thấy " + get() + " kết quả.");
                } catch (Exception ex) {
                    lblStatus.setText("Lỗi đọc file");
                }
                btnSearch.setEnabled(true);
            }
        };
        worker.execute();
    }
}