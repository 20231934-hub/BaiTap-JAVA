package vn.edu.eaut.lab4;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.util.Vector;

public class ProductManagerFrame extends JFrame {
    private JTextField txtId = new JTextField(10);
    private JTextField txtName = new JTextField(10);
    private JTextField txtPrice = new JTextField(10);
    private DefaultTableModel model;
    private JTable table;
    private JLabel lblStatus = new JLabel("Sẵn sàng");
    private final File file = new File("products.csv");

    public ProductManagerFrame() {
        setTitle("Bài 10 - Quản lý Sản Phẩm CSV");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel pnlInput = new JPanel(new GridLayout(3,2,5,5));
        pnlInput.add(new JLabel("Mã SP:")); pnlInput.add(txtId);
        pnlInput.add(new JLabel("Tên SP:")); pnlInput.add(txtName);
        pnlInput.add(new JLabel("Đơn giá:")); pnlInput.add(txtPrice);
        
        JPanel pnlBtns = new JPanel();
        JButton btnAdd = new JButton("Thêm"); JButton btnEdit = new JButton("Sửa");
        JButton btnDel = new JButton("Xóa"); JButton btnSave = new JButton("Lưu CSV");
        JButton btnLoad = new JButton("Đọc CSV");
        pnlBtns.add(btnAdd); pnlBtns.add(btnEdit); pnlBtns.add(btnDel); pnlBtns.add(btnSave); pnlBtns.add(btnLoad);
        
        String[] cols = {"Mã SP", "Tên SP", "Đơn giá"};
        model = new DefaultTableModel(cols, 0);
        table = new JTable(model);
        
        JPanel pnlTop = new JPanel(new BorderLayout());
        pnlTop.add(pnlInput, BorderLayout.CENTER); pnlTop.add(pnlBtns, BorderLayout.SOUTH);
        
        add(pnlTop, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(lblStatus, BorderLayout.SOUTH);
        
        btnAdd.addActionListener(e -> { model.addRow(new Object[]{txtId.getText(), txtName.getText(), txtPrice.getText()}); clear(); });
        btnDel.addActionListener(e -> { int r = table.getSelectedRow(); if (r>=0) model.removeRow(r); });
        btnEdit.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r>=0) { model.setValueAt(txtId.getText(), r, 0); model.setValueAt(txtName.getText(), r, 1); model.setValueAt(txtPrice.getText(), r, 2); clear(); }
        });
        
        table.getSelectionModel().addListSelectionListener(e -> {
            int r = table.getSelectedRow();
            if (r>=0) { txtId.setText(model.getValueAt(r,0).toString()); txtName.setText(model.getValueAt(r,1).toString()); txtPrice.setText(model.getValueAt(r,2).toString()); }
        });
        
        btnSave.addActionListener(e -> saveData());
        btnLoad.addActionListener(e -> loadData());
    }
    
    private void clear() { txtId.setText(""); txtName.setText(""); txtPrice.setText(""); }
    
    private void saveData() {
        lblStatus.setText("Đang lưu...");
        SwingWorker<Void, Void> w = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                try(BufferedWriter bw = Files.newBufferedWriter(file.toPath())) {
                    for(int i=0; i<model.getRowCount(); i++) {
                        bw.write(model.getValueAt(i,0) + "," + model.getValueAt(i,1) + "," + model.getValueAt(i,2) + "\n");
                    }
                }
                return null;
            }
            @Override
            protected void done() { lblStatus.setText("Lưu xong!"); }
        };
        w.execute();
    }
    
    private void loadData() {
        if(!file.exists()) return;
        lblStatus.setText("Đang đọc..."); model.setRowCount(0);
        SwingWorker<Void, String[]> w = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                try(BufferedReader br = Files.newBufferedReader(file.toPath())) {
                    String l; while((l=br.readLine())!=null) publish(l.split(","));
                }
                return null;
            }
            @Override
            protected void process(java.util.List<String[]> chunks) { for(String[] r:chunks) model.addRow(r); }
            @Override
            protected void done() { lblStatus.setText("Đọc xong!"); }
        };
        w.execute();
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductManagerFrame().setVisible(true));
    }
}