package vn.edu.eaut.lab4;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.file.Files;
import java.util.List;

public class CsvStatsFrame extends JFrame {
    private JButton btnLoad;
    private JTable table;
    private DefaultTableModel model;
    private JLabel lblStats;

    public CsvStatsFrame() {
        setTitle("Bài 8 - Đọc CSV Điểm Sinh Viên");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        btnLoad = new JButton("Đọc file CSV (Data mẫu)");
        lblStats = new JLabel("Thống kê: ");
        String[] cols = {"Mã SV", "Họ Tên", "Điểm"};
        model = new DefaultTableModel(cols, 0);
        table = new JTable(model);
        
        add(btnLoad, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(lblStats, BorderLayout.SOUTH);
        
        btnLoad.addActionListener(e -> loadCsv());
    }

    private void loadCsv() {
        btnLoad.setEnabled(false);
        model.setRowCount(0);
        
        // Tạo file mẫu
        File f = new File("sv.csv");
        try {
            if(!f.exists()) Files.writeString(f.toPath(), "SV01,Nguyen Van A,8.5\nSV02,Tran Thi B,7.0\nSV03,Le Van C,9.0\n");
        } catch (Exception ignored) {}

        SwingWorker<Void, Object[]> worker = new SwingWorker<>() {
            double total = 0, max = -1;
            int count = 0;
            String topSv = "";
            @Override
            protected Void doInBackground() throws Exception {
                try (BufferedReader br = Files.newBufferedReader(f.toPath())) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] p = line.split(",");
                        if (p.length == 3) {
                            double d = Double.parseDouble(p[2]);
                            total += d; count++;
                            if (d > max) { max = d; topSv = p[1]; }
                            publish((Object[]) p);
                        }
                    }
                }
                return null;
            }
            @Override
            protected void process(List<Object[]> chunks) {
                for(Object[] r : chunks) model.addRow(r);
            }
            @Override
            protected void done() {
                if (count > 0) lblStats.setText(String.format("TB: %.2f | Cao nhất: %s (%.1f)", total/count, topSv, max));
                btnLoad.setEnabled(true);
            }
        };
        worker.execute();
    }
}