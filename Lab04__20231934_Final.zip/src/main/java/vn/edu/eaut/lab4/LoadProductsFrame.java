package vn.edu.eaut.lab4;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class LoadProductsFrame extends JFrame {
    private JButton btnLoad;
    private JProgressBar progress;
    private JLabel lblStatus;
    private DefaultTableModel model;

    public LoadProductsFrame() {
        setTitle("Bài 9 - Tải Sản Phẩm");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        btnLoad = new JButton("Tải Sản Phẩm");
        progress = new JProgressBar(0, 100); progress.setStringPainted(true);
        lblStatus = new JLabel("Chưa tải");
        
        String[] cols = {"Mã SP", "Tên SP", "Đơn giá"};
        model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        
        JPanel pnlTop = new JPanel(new GridLayout(3,1));
        pnlTop.add(btnLoad); pnlTop.add(progress); pnlTop.add(lblStatus);
        
        add(pnlTop, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        
        btnLoad.addActionListener(e -> loadData());
    }

    private void loadData() {
        btnLoad.setEnabled(false); model.setRowCount(0); lblStatus.setText("Đang kết nối CSDL...");
        progress.setValue(0);
        
        SwingWorker<Void, Object[]> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                Object[][] data = {{"SP01", "Bàn phím", 250000}, {"SP02", "Chuột", 150000}, {"SP03", "Màn hình", 2500000}, {"SP04", "Tai nghe", 450000}};
                for (int i = 0; i < data.length; i++) {
                    Thread.sleep(800); // Giả lập mạng chậm
                    publish(data[i]);
                    setProgress((i + 1) * 100 / data.length);
                }
                return null;
            }
            @Override
            protected void process(List<Object[]> chunks) {
                for (Object[] row : chunks) model.addRow(row);
            }
            @Override
            protected void done() {
                lblStatus.setText("Đã tải xong!"); btnLoad.setEnabled(true); progress.setValue(100);
            }
        };
        worker.addPropertyChangeListener(evt -> {
            if ("progress".equals(evt.getPropertyName())) progress.setValue((int) evt.getNewValue());
        });
        worker.execute();
    }
}