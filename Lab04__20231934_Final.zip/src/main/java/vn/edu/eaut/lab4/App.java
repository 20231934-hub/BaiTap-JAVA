package vn.edu.eaut.lab4;
import javax.swing.*;
import java.awt.*;

public class App extends JFrame {
    public App() {
        setTitle("Menu Lab 4 - Vũ Duy Thái Sơn");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(10, 1, 5, 5));

        JButton btn1 = new JButton("Bài 1: Đếm ngược");
        JButton btn2 = new JButton("Bài 2: Mô phỏng tải dữ liệu");
        JButton btn3 = new JButton("Bài 3: Tổng số nguyên tố");
        JButton btn4 = new JButton("Bài 4: Tìm số Fibonacci");
        JButton btn5 = new JButton("Bài 5: Đếm dòng file");
        JButton btn6 = new JButton("Bài 6: Hủy tác vụ đang chạy");
        JButton btn7 = new JButton("Bài 7: Tìm từ khóa trong File");
        JButton btn8 = new JButton("Bài 8: Đọc file CSV (Thống kê)");
        JButton btn9 = new JButton("Bài 9: Tải Sản phẩm (Giả lập delay)");
        JButton btn10 = new JButton("Bài 10: Quản lý SP (Thêm, Sửa, Xóa CSV)");

        btn1.addActionListener(e -> new CountdownFrame().setVisible(true));
        btn2.addActionListener(e -> new ProgressDemoFrame().setVisible(true));
        btn3.addActionListener(e -> new PrimeSumFrame().setVisible(true));
        btn4.addActionListener(e -> new FibonacciFrame().setVisible(true));
        btn5.addActionListener(e -> new FileLineCounterFrame().setVisible(true));
        btn6.addActionListener(e -> new CancelTaskFrame().setVisible(true));
        btn7.addActionListener(e -> new SearchWordFrame().setVisible(true));
        btn8.addActionListener(e -> new CsvStatsFrame().setVisible(true));
        btn9.addActionListener(e -> new LoadProductsFrame().setVisible(true));
        btn10.addActionListener(e -> new ProductManagerFrame().setVisible(true));

        add(btn1); add(btn2); add(btn3); add(btn4); add(btn5);
        add(btn6); add(btn7); add(btn8); add(btn9); add(btn10);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new App().setVisible(true);
        });
    }
}
