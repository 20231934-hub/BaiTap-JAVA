package vn.edu.eaut.lab4;
import javax.swing.*;
import java.awt.*;
import java.util.concurrent.CancellationException;

public class CancelTaskFrame extends JFrame {
    private JButton btnLoad, btnCancel;
    private JProgressBar progressBar;
    private JLabel lblStatus;
    private SwingWorker<Void, Integer> worker;

    public CancelTaskFrame() {
        setTitle("Bài 6 - Hủy tác vụ");
        setSize(450, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        btnLoad = new JButton("Bắt đầu");
        btnCancel = new JButton("Hủy");
        btnCancel.setEnabled(false);
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        lblStatus = new JLabel("Chưa bắt đầu");
        
        JPanel pnlBtns = new JPanel();
        pnlBtns.add(btnLoad); pnlBtns.add(btnCancel);
        
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.add(pnlBtns);
        panel.add(progressBar);
        panel.add(lblStatus);
        add(panel);
        
        btnLoad.addActionListener(e -> startTask());
        btnCancel.addActionListener(e -> {
            if (worker != null && !worker.isDone()) worker.cancel(true);
        });
    }

    private void startTask() {
        btnLoad.setEnabled(false);
        btnCancel.setEnabled(true);
        progressBar.setValue(0);
        lblStatus.setText("Đang chạy...");
        worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i += 5) {
                    if (isCancelled()) return null;
                    setProgress(i);
                    Thread.sleep(500);
                }
                return null;
            }
            @Override
            protected void done() {
                btnLoad.setEnabled(true);
                btnCancel.setEnabled(false);
                if (isCancelled()) {
                    lblStatus.setText("Đã hủy tác vụ");
                    progressBar.setValue(0);
                } else {
                    lblStatus.setText("Hoàn tất");
                    progressBar.setValue(100);
                }
            }
        };
        worker.addPropertyChangeListener(evt -> {
            if ("progress".equals(evt.getPropertyName())) {
                progressBar.setValue((int) evt.getNewValue());
            }
        });
        worker.execute();
    }
}