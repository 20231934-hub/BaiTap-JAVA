package vn.edu.eaut.lab6.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentTest {

    @Test
    void defaultConstructorShouldCreateEmptyStudent() {
        Student student = new Student();

        assertNull(student.getId());
        assertNull(student.getName());
        assertNull(student.getClassName());
        assertNull(student.getEmail());
    }

    @Test
    void constructorShouldPopulateAllFields() {
        Student student = new Student("SV01", "Nguyen Van A", "CNTT1", "a@example.com");

        assertAll(
                () -> assertEquals("SV01", student.getId()),
                () -> assertEquals("Nguyen Van A", student.getName()),
                () -> assertEquals("CNTT1", student.getClassName()),
                () -> assertEquals("a@example.com", student.getEmail())
        );
    }

    @Test
    void settersShouldUpdateAllFields() {
        Student student = new Student();

        student.setId("SV02");
        student.setName("Tran Thi B");
        student.setClassName("CNTT2");
        student.setEmail("b@example.com");

        assertAll(
                () -> assertEquals("SV02", student.getId()),
                () -> assertEquals("Tran Thi B", student.getName()),
                () -> assertEquals("CNTT2", student.getClassName()),
                () -> assertEquals("b@example.com", student.getEmail())
        );
    }
}
