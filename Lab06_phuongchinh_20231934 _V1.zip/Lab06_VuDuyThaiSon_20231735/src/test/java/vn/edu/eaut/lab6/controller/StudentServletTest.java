package vn.edu.eaut.lab6.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import vn.edu.eaut.lab6.model.Student;
import vn.edu.eaut.lab6.store.StudentStore;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

class StudentServletTest {

    @BeforeEach
    void setUp() throws Exception {
        Field field = StudentStore.class.getDeclaredField("students");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Student> students = (List<Student>) field.get(null);
        students.clear();
        students.add(new Student("SV01", "Alpha", "CNTT1", "alpha@example.com"));
        students.add(new Student("SV02", "Beta", "CNTT2", "beta@example.com"));
    }

    @Test
    void doGetShouldListStudentsWhenUserIsNotFiltering() throws Exception {
        StudentServlet servlet = new StudentServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);
        RequestDispatcher dispatcher = mock(RequestDispatcher.class);

        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn("USER");
        when(request.getParameter("action")).thenReturn(null);
        when(request.getParameter("keyword")).thenReturn(null);
        when(request.getRequestDispatcher("/student-list.jsp")).thenReturn(dispatcher);

        servlet.doGet(request, response);

        verify(request).setAttribute(eq("students"), anyList());
        verify(dispatcher).forward(request, response);
    }

    @Test
    void doGetShouldFilterStudentsByKeyword() throws Exception {
        StudentServlet servlet = new StudentServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);
        RequestDispatcher dispatcher = mock(RequestDispatcher.class);

        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn("USER");
        when(request.getParameter("action")).thenReturn(null);
        when(request.getParameter("keyword")).thenReturn("beta");
        when(request.getRequestDispatcher("/student-list.jsp")).thenReturn(dispatcher);

        servlet.doGet(request, response);

        verify(request).setAttribute(eq("keyword"), eq("beta"));
        verify(request).setAttribute(eq("students"), anyList());
        verify(dispatcher).forward(request, response);
    }

    @Test
    void doGetShouldDeleteStudentForAdmin() throws Exception {
        StudentServlet servlet = new StudentServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);

        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn("ADMIN");
        when(request.getParameter("action")).thenReturn("delete");
        when(request.getParameter("id")).thenReturn("SV01");
        when(request.getContextPath()).thenReturn("/lab06");

        servlet.doGet(request, response);

        verify(response).sendRedirect("/lab06/students");
        assert StudentStore.findById("SV01") == null;
    }

    @Test
    void doGetShouldDenyDeleteForNonAdmin() throws Exception {
        StudentServlet servlet = new StudentServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);

        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn("USER");
        when(request.getParameter("action")).thenReturn("delete");
        when(request.getContextPath()).thenReturn("/lab06");

        servlet.doGet(request, response);

        verify(response).sendRedirect("403.jsp");
    }

    @Test
    void doPostShouldAddStudentForAdmin() throws Exception {
        StudentServlet servlet = new StudentServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);

        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn("ADMIN");
        when(request.getParameter("action")).thenReturn("add");
        when(request.getParameter("id")).thenReturn("SV03");
        when(request.getParameter("name")).thenReturn("Gamma");
        when(request.getParameter("className")).thenReturn("CNTT3");
        when(request.getParameter("email")).thenReturn("gamma@example.com");
        when(request.getContextPath()).thenReturn("/lab06");

        servlet.doPost(request, response);

        verify(response).sendRedirect("/lab06/students");
        assert StudentStore.findById("SV03") != null;
    }

    @Test
    void doPostShouldRejectNonAdminRequests() throws Exception {
        StudentServlet servlet = new StudentServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);

        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn("USER");

        servlet.doPost(request, response);

        verify(response).sendRedirect("403.jsp");
    }
}
