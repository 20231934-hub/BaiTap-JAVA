package vn.edu.eaut.lab6.store;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import vn.edu.eaut.lab6.model.Student;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class StudentStoreTest {

    @BeforeEach
    void setUp() throws Exception {
        Field field = StudentStore.class.getDeclaredField("students");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Student> students = (List<Student>) field.get(null);
        students.clear();
    }

    @Test
    void addShouldStoreStudentAndFindAllShouldReturnIt() {
        Student student = new Student("SV01", "Alice", "CNTT1", "alice@example.com");

        StudentStore.add(student);

        assertEquals(1, StudentStore.findAll().size());
        assertSame(student, StudentStore.findAll().get(0));
    }

    @Test
    void findByIdShouldReturnMatchingStudent() {
        Student student = new Student("SV02", "Bob", "CNTT2", "bob@example.com");
        StudentStore.add(student);

        Student found = StudentStore.findById("SV02");

        assertNotNull(found);
        assertEquals("Bob", found.getName());
    }

    @Test
    void deleteShouldRemoveMatchingStudent() {
        StudentStore.add(new Student("SV03", "Charlie", "CNTT3", "charlie@example.com"));

        boolean deleted = StudentStore.delete("SV03");

        assertTrue(deleted);
        assertNull(StudentStore.findById("SV03"));
        assertEquals(0, StudentStore.findAll().size());
    }

    @Test
    void updateShouldReplaceExistingStudent() {
        StudentStore.add(new Student("SV04", "David", "CNTT4", "david@example.com"));

        Student updated = new Student("SV04", "David Updated", "CNTT5", "updated@example.com");
        StudentStore.update(updated);

        Student stored = StudentStore.findById("SV04");
        assertNotNull(stored);
        assertEquals("David Updated", stored.getName());
        assertEquals("CNTT5", stored.getClassName());
        assertEquals("updated@example.com", stored.getEmail());
    }
}
