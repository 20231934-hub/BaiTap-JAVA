package vn.edu.eaut.lab6.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

class LoginServletTest {

    @Test
    void doPostShouldRedirectAdminOnValidCredentials() throws Exception {
        LoginServlet servlet = new LoginServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);

        when(request.getParameter("username")).thenReturn("admin");
        when(request.getParameter("password")).thenReturn("123456");
        when(request.getSession()).thenReturn(session);
        when(request.getContextPath()).thenReturn("/lab06");

        servlet.doPost(request, response);

        verify(session).setAttribute("username", "admin");
        verify(session).setAttribute("role", "ADMIN");
        verify(response).sendRedirect("/lab06/dashboard.jsp");
    }

    @Test
    void doPostShouldRedirectUserOnValidCredentials() throws Exception {
        LoginServlet servlet = new LoginServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpSession session = mock(HttpSession.class);

        when(request.getParameter("username")).thenReturn("user");
        when(request.getParameter("password")).thenReturn("123456");
        when(request.getSession()).thenReturn(session);
        when(request.getContextPath()).thenReturn("/lab06");

        servlet.doPost(request, response);

        verify(session).setAttribute("username", "user");
        verify(session).setAttribute("role", "USER");
        verify(response).sendRedirect("/lab06/dashboard.jsp");
    }

    @Test
    void doPostShouldForwardToLoginPageOnInvalidCredentials() throws Exception {
        LoginServlet servlet = new LoginServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        RequestDispatcher dispatcher = mock(RequestDispatcher.class);

        when(request.getParameter("username")).thenReturn("guest");
        when(request.getParameter("password")).thenReturn("wrong");
        when(request.getRequestDispatcher("/login.jsp")).thenReturn(dispatcher);

        servlet.doPost(request, response);

        verify(request).setAttribute("error", "Sai tên đăng nhập hoặc mật khẩu");
        verify(request).getRequestDispatcher("/login.jsp");
        verify(dispatcher).forward(request, response);
    }
}
