<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Sinh Viên</title>
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold d-flex align-items-center" href="dashboard.jsp">
                <i class="bi bi-mortarboard-fill text-primary me-2 fs-4"></i> StudentPortal
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.jsp"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active fw-semibold" href="students"><i class="bi bi-people-fill me-1"></i> Quản lý sinh viên</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center text-light gap-3">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-person-circle fs-4 me-2 text-primary"></i>
                        <div>
                            <div class="fw-bold small">${sessionScope.username}</div>
                            <span class="badge ${sessionScope.role == 'ADMIN' ? 'bg-danger' : 'bg-info'} text-uppercase" style="font-size: 0.65rem;">
                                ${sessionScope.role}
                            </span>
                        </div>
                    </div>
                    <a href="logout" class="btn btn-outline-light btn-sm rounded-pill px-3">
                        <i class="bi bi-box-arrow-right me-1"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="bi bi-people text-primary me-2"></i>Danh Sách Sinh Viên</h3>
                <p class="text-muted small mb-0">Quản lý và tra cứu thông tin sinh viên trong hệ thống</p>
            </div>
            <div class="d-flex gap-2">
                <a href="dashboard.jsp" class="btn btn-outline-secondary rounded-3">
                    <i class="bi bi-arrow-left me-1"></i> Dashboard
                </a>
                <c:if test="${sessionScope.role == 'ADMIN'}">
                    <a href="student-form.jsp" class="btn btn-primary rounded-3 shadow-sm">
                        <i class="bi bi-person-plus-fill me-1"></i> Thêm Sinh Viên Mới
                    </a>
                </c:if>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="card card-custom p-3 bg-white mb-4">
            <form action="students" method="get" class="row g-2 align-items-center">
                <div class="col-md-9 col-lg-10">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" name="keyword" value="${keyword}" class="form-control bg-light border-start-0 ps-0" placeholder="Nhập tên sinh viên cần tìm...">
                    </div>
                </div>
                <div class="col-md-3 col-lg-2 d-grid">
                    <button type="submit" class="btn btn-primary fw-semibold"><i class="bi bi-search me-1"></i> Tìm kiếm</button>
                </div>
            </form>
        </div>

        <!-- Table Card -->
        <div class="card card-custom bg-white overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Mã SV</th>
                            <th>Họ và Tên</th>
                            <th>Lớp</th>
                            <th>Email</th>
                            <th class="text-end pe-4">Hành Động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="sv" items="${students}">
                            <tr>
                                <td class="ps-4 fw-bold text-primary">${sv.id}</td>
                                <td class="fw-semibold text-dark">${sv.name}</td>
                                <%-- Single tag correction for safety --%>
                                <td><span class="badge bg-secondary-subtle text-secondary fw-medium px-2 py-1">${sv.className}</span></td>
                                <td class="text-muted"><i class="bi bi-envelope me-1"></i>${sv.email}</td>
                                <td class="text-end pe-4">
                                    <c:choose>
                                        <c:when test="${sessionScope.role == 'ADMIN'}">
                                            <a href="students?action=edit&id=${sv.id}" class="btn btn-sm btn-outline-primary me-1" title="Sửa">
                                                <i class="bi bi-pencil-square"></i> Sửa
                                            </a>
                                            <a href="students?action=delete&id=${sv.id}" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa sinh viên này?');" title="Xóa">
                                                <i class="bi bi-trash"></i> Xóa
                                            </a>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge bg-light text-muted border"><i class="bi bi-lock me-1"></i>Chỉ xem</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>

            <c:if test="${empty students}">
                <div class="text-center py-5">
                    <i class="bi bi-search text-muted display-4 mb-3 d-block"></i>
                    <h5 class="text-muted fw-normal">Không tìm thấy sinh viên nào phù hợp!</h5>
                    <p class="text-secondary small">Vui lòng thử tìm kiếm với từ khóa khác.</p>
                </div>
            </c:if>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>