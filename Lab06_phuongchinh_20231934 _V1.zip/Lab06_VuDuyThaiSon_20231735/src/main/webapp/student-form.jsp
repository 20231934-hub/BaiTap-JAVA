<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${student == null ? 'Thêm' : 'Sửa'} Sinh Viên</title>
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold d-flex align-items-center" href="dashboard.jsp">
                <i class="bi bi-mortarboard-fill text-primary me-2 fs-4"></i> StudentPortal
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.jsp"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active fw-semibold" href="students"><i class="bi bi-people-fill me-1"></i> Quản lý sinh viên</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center text-light gap-3">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-person-circle fs-4 me-2 text-primary"></i>
                        <div>
                            <div class="fw-bold small">${sessionScope.username}</div>
                            <span class="badge ${sessionScope.role == 'ADMIN' ? 'bg-danger' : 'bg-info'} text-uppercase" style="font-size: 0.65rem;">
                                ${sessionScope.role}
                            </span>
                        </div>
                    </div>
                    <a href="logout" class="btn btn-outline-light btn-sm rounded-pill px-3">
                        <i class="bi bi-box-arrow-right me-1"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container py-5 d-flex justify-content-center">
        <div class="card card-custom p-4 bg-white" style="max-width: 600px; width: 100%;">
            <div class="d-flex align-items-center border-bottom pb-3 mb-4">
                <div class="bg-primary-subtle text-primary p-3 rounded-circle me-3">
                    <i class="bi ${student == null ? 'bi-person-plus-fill' : 'bi-pencil-square'} fs-3"></i>
                </div>
                <div>
                    <h4 class="fw-bold text-dark mb-0">${student == null ? 'Thêm Sinh Viên Mới' : 'Cập Nhật Sinh Viên'}</h4>
                    <p class="text-muted small mb-0">Điền đầy đủ thông tin chi tiết sinh viên dưới đây</p>
                </div>
            </div>

            <form action="students" method="post">
                <input type="hidden" name="action" value="${student == null ? 'add' : 'update'}">

                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Mã sinh viên</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-card-heading text-muted"></i></span>
                        <input type="text" name="id" value="${student.id}" ${student != null ? 'readonly' : ''} class="form-control bg-light" placeholder="Nhập mã sinh viên (VD: SV001)..." required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Họ và Tên</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-person text-muted"></i></span>
                        <input type="text" name="name" value="${student.name}" class="form-control" placeholder="Nhập họ và tên..." required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Lớp học</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-building text-muted"></i></span>
                        <input type="text" name="className" value="${student.className}" class="form-control" placeholder="Nhập tên lớp..." required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold text-secondary">Địa chỉ Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-envelope text-muted"></i></span>
                        <input type="email" name="email" value="${student.email}" class="form-control" placeholder="example@domain.com" required>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-2 border-top">
                    <a href="students" class="btn btn-outline-secondary px-4 rounded-3">
                        <i class="bi bi-x-circle me-1"></i> Hủy bỏ
                    </a>
                    <button type="submit" class="btn btn-primary px-4 rounded-3 fw-semibold">
                        <i class="bi bi-check-circle me-1"></i> Lưu thông tin
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>