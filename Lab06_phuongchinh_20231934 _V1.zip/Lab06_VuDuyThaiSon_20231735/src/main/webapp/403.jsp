<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Truy cập bị từ chối</title>
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body class="bg-light d-flex align-items-center justify-content-center min-vh-100">
    <div class="text-center p-4">
        <div class="card card-custom p-5 bg-white shadow-lg border-0" style="max-width: 500px;">
            <div class="mb-3 text-danger">
                <i class="bi bi-shield-lock-fill display-1"></i>
            </div>
            <h1 class="fw-bold text-danger mb-2">403 - CẤM TRUY CẬP</h1>
            <h5 class="text-dark mb-3">Bạn không có quyền thực hiện chức năng này!</h5>
            <p class="text-muted small mb-4">
                Chức năng này yêu cầu quyền quản trị <strong>ADMIN</strong>. Tài khoản hiện tại của bạn là <strong>USER</strong> chỉ có quyền xem dữ liệu.
            </p>
            <div>
                <a href="dashboard.jsp" class="btn btn-primary px-4 py-2 rounded-3 fw-semibold">
                    <i class="bi bi-house-door me-1"></i> Quay lại Dashboard
                </a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>