<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - Quản Lý Sinh Viên</title>
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body class="login-container">
    <div class="container d-flex justify-content-center">
        <div class="card login-card p-4 shadow-lg border-0 bg-white">
            <div class="text-center mb-4">
                <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                    <i class="bi bi-mortarboard-fill fs-2"></i>
                </div>
                <h3 class="fw-bold text-dark">Đăng Nhập Hệ Thống</h3>
                <p class="text-muted small">Lab 06 - Quản Lý Sinh Viên</p>
            </div>

            <form action="login" method="post">
                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Tài khoản</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-muted"></i></span>
                        <input type="text" name="username" class="form-control bg-light border-start-0 ps-0" placeholder="Nhập tên đăng nhập..." required autocomplete="off">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold text-secondary">Mật khẩu</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-muted"></i></span>
                        <input type="password" name="password" class="form-control bg-light border-start-0 ps-0" placeholder="Nhập mật khẩu..." required>
                    </div>
                </div>

                <% if (request.getAttribute("error") != null) { %>
                    <div class="alert alert-danger d-flex align-items-center py-2 px-3 small rounded-3 mb-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <div>${error}</div>
                    </div>
                <% } %>

                <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold rounded-3 mb-3">
                    <i class="bi bi-box-arrow-in-right me-1"></i> Đăng nhập
                </button>
            </form>

            <div class="p-3 bg-light rounded-3 text-muted small">
                <div class="fw-bold mb-1 text-dark"><i class="bi bi-info-circle me-1"></i> Tải khoản dùng thử:</div>
                <div class="d-flex justify-content-between mb-1">
                    <span><i class="bi bi-shield-lock-fill text-danger me-1"></i> <strong>Admin:</strong> admin / 123456</span>
                    <span class="badge bg-danger-subtle text-danger">Toàn quyền</span>
                </div>
                <div class="d-flex justify-content-between">
                    <span><i class="bi bi-person-fill text-info me-1"></i> <strong>User:</strong> user / 123456</span>
                    <span class="badge bg-info-subtle text-info">Chỉ xem</span>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>