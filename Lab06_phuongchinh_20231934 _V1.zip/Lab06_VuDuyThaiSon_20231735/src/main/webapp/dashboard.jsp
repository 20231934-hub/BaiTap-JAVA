<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="vn.edu.eaut.lab6.store.StudentStore" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Quản Lý Sinh Viên</title>
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold d-flex align-items-center" href="dashboard.jsp">
                <i class="bi bi-mortarboard-fill text-primary me-2 fs-4"></i> StudentPortal
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active fw-semibold" href="dashboard.jsp"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="students"><i class="bi bi-people-fill me-1"></i> Quản lý sinh viên</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center text-light gap-3">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-person-circle fs-4 me-2 text-primary"></i>
                        <div>
                            <div class="fw-bold small">${sessionScope.username}</div>
                            <span class="badge ${sessionScope.role == 'ADMIN' ? 'bg-danger' : 'bg-info'} text-uppercase" style="font-size: 0.65rem;">
                                ${sessionScope.role}
                            </span>
                        </div>
                    </div>
                    <a href="logout" class="btn btn-outline-light btn-sm rounded-pill px-3">
                        <i class="bi bi-box-arrow-right me-1"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container py-5">
        <div class="p-4 mb-4 rounded-4 bg-white shadow-sm border">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="fw-bold text-dark mb-1">Xin chào, ${sessionScope.username}! 👋</h2>
                    <p class="text-muted mb-0">Chào mừng bạn quay trở lại với Hệ thống Quản lý Sinh viên - Lab 06.</p>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <a href="students" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
                        <i class="bi bi-arrow-right-circle me-1"></i> Đi tới Quản lý Sinh viên
                    </a>
                </div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card card-custom p-4 bg-white h-100 border-start border-4 border-primary">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted small uppercase fw-semibold mb-1">Tổng Số Sinh Viên</p>
                            <h2 class="fw-bold mb-0 text-primary"><%= StudentStore.findAll().size() %></h2>
                        </div>
                        <div class="bg-primary-subtle p-3 rounded-circle text-primary">
                            <i class="bi bi-people fs-2"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-custom p-4 bg-white h-100 border-start border-4 border-success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted small uppercase fw-semibold mb-1">Vai Trò Hiện Tại</p>
                            <h4 class="fw-bold mb-0 text-success">${sessionScope.role}</h4>
                        </div>
                        <div class="bg-success-subtle p-3 rounded-circle text-success">
                            <i class="bi bi-shield-check fs-2"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-custom p-4 bg-white h-100 border-start border-4 border-info">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted small uppercase fw-semibold mb-1">Thời Gian Đăng Nhập</p>
                            <div class="fw-bold text-dark small" style="word-break: break-all;">
                                ${sessionScope.loginTime}
                            </div>
                        </div>
                        <div class="bg-info-subtle p-3 rounded-circle text-info">
                            <i class="bi bi-clock-history fs-2"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>