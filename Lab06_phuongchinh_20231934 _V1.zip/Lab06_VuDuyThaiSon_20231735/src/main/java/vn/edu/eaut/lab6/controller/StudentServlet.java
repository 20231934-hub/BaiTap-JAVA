package vn.edu.eaut.lab6.controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.edu.eaut.lab6.model.Student;
import vn.edu.eaut.lab6.store.StudentStore;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String keyword = request.getParameter("keyword");
        
        // Bài 9: Kiểm tra quyền Admin khi truy cập form thêm/sửa
        String role = (String) request.getSession().getAttribute("role");
        
        if ("delete".equals(action)) {
            if(!"ADMIN".equals(role)) { response.sendRedirect("403.jsp"); return; }
            String id = request.getParameter("id");
            StudentStore.delete(id);
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        } else if ("edit".equals(action)) {
            if(!"ADMIN".equals(role)) { response.sendRedirect("403.jsp"); return; }
            String id = request.getParameter("id");
            Student s = StudentStore.findById(id);
            request.setAttribute("student", s);
            request.getRequestDispatcher("/student-form.jsp").forward(request, response);
            return;
        }
        
        List<Student> list = StudentStore.findAll();
        // Bài 6: Chức năng tìm kiếm
        if(keyword != null && !keyword.trim().isEmpty()) {
            list = list.stream().filter(s -> s.getName().toLowerCase().contains(keyword.toLowerCase())).collect(Collectors.toList());
            request.setAttribute("keyword", keyword);
        }
        
        request.setAttribute("students", list);
        request.getRequestDispatcher("/student-list.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String role = (String) request.getSession().getAttribute("role");
        if(!"ADMIN".equals(role)) { response.sendRedirect("403.jsp"); return; }
        
        String action = request.getParameter("action");
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String className = request.getParameter("className");
        String email = request.getParameter("email");
        
        Student student = new Student(id, name, className, email);
        if("update".equals(action)) {
            StudentStore.update(student); // Bài 8: Cập nhật
        } else {
            StudentStore.add(student); // Thêm mới
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }
}