package vn.edu.eaut.lab6.controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String user = request.getParameter("username");
        String pass = request.getParameter("password");
        
        // Bài 9: Phân quyền Admin/User
        if ("admin".equals(user) && "123456".equals(pass)) {
            HttpSession session = request.getSession();
            session.setAttribute("username", user);
            session.setAttribute("role", "ADMIN");
            session.setAttribute("loginTime", new java.util.Date()); // Cho Bài 10
            response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
        } else if ("user".equals(user) && "123456".equals(pass)) {
            HttpSession session = request.getSession();
            session.setAttribute("username", user);
            session.setAttribute("role", "USER");
            session.setAttribute("loginTime", new java.util.Date());
            response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
        } else {
            request.setAttribute("error", "Sai tên đăng nhập hoặc mật khẩu");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
}