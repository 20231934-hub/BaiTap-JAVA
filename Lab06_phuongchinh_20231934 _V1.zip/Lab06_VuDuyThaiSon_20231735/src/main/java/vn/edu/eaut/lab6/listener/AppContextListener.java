package vn.edu.eaut.lab6.listener;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import vn.edu.eaut.lab6.model.Student;
import vn.edu.eaut.lab6.store.StudentStore;

@WebListener
public class AppContextListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Ung dung Lab 6 da khoi dong");
        // Bài 12: Khởi tạo 5 sinh viên mẫu
        StudentStore.add(new Student("SV01", "Vu Duy Thai Son", "CNTT1", "son@gmail.com"));
        StudentStore.add(new Student("SV02", "Nguyen Van A", "CNTT1", "a@gmail.com"));
        StudentStore.add(new Student("SV03", "Tran Thi B", "CNTT2", "b@gmail.com"));
        StudentStore.add(new Student("SV04", "Le Van C", "CNTT2", "c@gmail.com"));
        StudentStore.add(new Student("SV05", "Pham Thi D", "CNTT3", "d@gmail.com"));
    }
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Ung dung Lab 6 da dung. Tong so sinh vien dang luu: " + StudentStore.findAll().size());
    }
}