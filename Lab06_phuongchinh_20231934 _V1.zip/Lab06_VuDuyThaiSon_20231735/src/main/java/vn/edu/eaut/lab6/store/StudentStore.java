package vn.edu.eaut.lab6.store;
import vn.edu.eaut.lab6.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentStore {
    private static final List<Student> students = new ArrayList<>();
    
    // Bài 12: Khởi tạo dữ liệu mẫu thông qua Listener thay vì static block
    public static List<Student> findAll() { return students; }
    public static void add(Student student) { students.add(student); }
    public static boolean delete(String id) {
        return students.removeIf(s -> s.getId().equals(id));
    }
    public static Student findById(String id) {
        return students.stream().filter(s -> s.getId().equals(id)).findFirst().orElse(null);
    }
    public static void update(Student st) {
        for(int i=0; i<students.size(); i++){
            if(students.get(i).getId().equals(st.getId())){
                students.set(i, st); break;
            }
        }
    }
}