package vn.edu.eaut.lab6.filter;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

// Bài 11: Ghi log truy cập
@WebFilter("/*")
public class LogFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpSession session = request.getSession(false);
        String user = (session != null && session.getAttribute("username") != null) ? (String) session.getAttribute("username") : "Guest";
        System.out.println("[LOG] " + new Date() + " | User: " + user + " | Method: " + request.getMethod() + " | URI: " + request.getRequestURI());
        chain.doFilter(req, resp);
    }
}