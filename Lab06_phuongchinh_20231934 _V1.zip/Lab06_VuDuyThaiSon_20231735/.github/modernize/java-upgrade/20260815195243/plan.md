# Upgrade Plan: lab06-student-web (20260815195243)

- **Generated**: 2026-08-16 19:52:43
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 25: D:\Java\bin (available and suitable for the project target runtime)
- JDK 26: D:\orcle jdk\bin (available, newer than target, used for compatibility validation)

**Build Tools**
- Maven 3.9.16: D:\apache-maven-3.9.16-bin\apache-maven-3.9.16\bin

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

- Upgrade to the latest LTS Java runtime with the smallest viable compatibility change.
- Prefer a straightforward JDK 21 compatibility update while preserving the existing Jakarta Servlet 6 web application behavior.
- Keep the project build reproducible and compile cleanly with the target JDK and Maven.

## Options

- Working branch: appmod/java-upgrade-20260815195243
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | --------------------- | --------------- |
| Java | 17 | 25 | User requested Java 25 LTS runtime |
| Maven Compiler Plugin | default (no explicit version) | 3.11.0 | Recommended for Java 21 support and reliable compilation |
| Jakarta Servlet API | 6.0.0 | 6.0.0 | Already compatible with Java 21 |
| jakarta.servlet.jsp.jstl | 3.0.1 | 3.0.1 | Already compatible with Java 21 |
| Maven WAR Plugin | 3.3.2 | 3.3.2+ | Works with Java 21; align with modern plugin behavior |

## Derived Upgrades

- Java 17 → Java 25 requires compiler source/target update and a modern Maven toolchain compatible with the target JDK.
- Java 25 is the current LTS runtime target and remains compatible with the project’s existing Jakarta Servlet 6 API usage.
- No Spring Boot or Kotlin migration is required because this project is a simple Jakarta Servlet web application.

## Impact Analysis

### Subsection: Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | maven.compiler.source | 17 | upgrade | 25 | User requested Java 25 LTS |
| pom.xml | maven.compiler.target | 17 | upgrade | 25 | User requested Java 25 LTS |
| pom.xml | maven.compiler.release | (unset) | add | 25 | Align the bytecode level with the target LTS runtime |
| pom.xml | maven-compiler-plugin | implicit | add | 3.14.0 | Recommended Java 25 compatibility and explicit build control |
| pom.xml | maven-war-plugin | 3.3.2 | upgrade | 3.4.0+ | Align WAR packaging with modern Java runtime support |

### Subsection: Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| No Java source files require framework or package migration because they already use `jakarta.servlet.*` imports. | N/A | N/A | None required | Project already matches Jakarta EE 9+ API contracts |

### Subsection: Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|-----------------|---------|-----------------|--------|
| src/main/webapp/WEB-INF/web.xml | web-app version | 6.0 | Keep as 6.0 | Already compatible with Jakarta Servlet 6 and Java 21 |

### Subsection: CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| No CI/CD configuration detected in the repository | N/A | N/A | None required |

### Subsection: Risks & Warnings

- **Build tool compatibility**: Maven is already installed and supports Java 21, but the project currently declares Java 17. **Mitigation**: upgrade the compiler settings and validate with `mvn clean test` on JDK 21.
- **No automated test suite**: This project appears to have no unit tests, so a successful compile and full Maven test run will be the validation gate. **Mitigation**: use the existing build lifecycle as the authoritative verification step.

## Upgrade Steps

- Step 1: Setup Java 25 Toolchain
  - **Rationale**: The project must build on the target LTS JDK before any source-level change is made.
  - **Changes to Make**: Validate the available JDK 25-compatible toolchain and ensure Maven runs under it.
  - **Verification**: `java -version` and `mvn -version` with the Java 25+ path configured; expected Java 25+ runtime detected.

- Step 2: Update Java Build Settings
  - **Rationale**: The project currently targets Java 17; Java 25 requires the compiler source/target to be aligned with the runtime.
  - **Changes to Make**: Apply all Dependency Changes in the updated compiler and WAR plugin settings in `pom.xml`.
  - **Verification**: `mvn clean test-compile -q` using Java 25+; expected successful compilation of main and test sources.

- Step 3: Final Validation
  - **Rationale**: Confirm the application still builds and boots under Java 25 with a full project test pass.
  - **Changes to Make**: Run the full Maven test lifecycle and fix any residual compatibility issue until the build is green.
  - **Verification**: `mvn clean test -q` using Java 25+; expected 100% pass or documented baseline mismatch if no tests exist.
